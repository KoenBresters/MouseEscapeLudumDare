﻿using UnityEngine;

public class DestroyHealth : AbsHealth {

    public GameObject death_particle;
    public override void onDeath(GameObject by)
    {
        if(death_particle != null) Instantiate(death_particle, transform.localPosition, transform.localRotation);
        Destroy(gameObject);
    }
}
