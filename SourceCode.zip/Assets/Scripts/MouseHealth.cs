﻿using UnityEngine;
using System.Linq;
using UnityEngine.SceneManagement;

public class MouseHealth : DestroyHealth {

    public MouseMain main;

    public override void onDeath(GameObject by)
    {
        if (main.isPlayer)
        {
            IOrderedEnumerable<Collider2D> a = Physics2D.OverlapCircleAll(transform.position, Mathf.Infinity).OrderBy(x => Vector2.Distance(x.transform.position, transform.position));
            if(a.ToArray().Length <= 0)
            {
                Manager.current.fader.FadeTo(SceneManager.GetActiveScene().name);
                return;
            }
            foreach (Collider2D i in a)
            {
                if(i.GetComponent<MouseMain>() != null)
                {
                    Manager.current.SetPlayer(i.GetComponent<MouseMain>());
                }
            }
        }
        base.onDeath(by);
    }
}
