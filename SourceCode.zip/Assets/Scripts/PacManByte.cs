﻿using UnityEngine;

public class PacManByte : MonoBehaviour {

    public float damage;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.GetComponent<AbsHealth>())
        {
            other.GetComponent<AbsHealth>().damage(damage, gameObject);
        }
    }
}
