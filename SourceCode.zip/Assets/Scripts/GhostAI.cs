﻿using UnityEngine;

public class GhostAI : MonoBehaviour {

    public float retargetRate;
    public float targetRange;
    private float nextRetarget;
    public float attackRate;
    private float nextAttack;
    private AbsHealth target;
    private Rigidbody2D rb;
    public float moveForce;
    public AbsAttack attacker;

    private void Start()
    {
        nextRetarget = Time.time + Random.value * retargetRate;
        nextAttack = Time.time + attackRate;
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update () {
		if(nextRetarget < Time.time)
        {
            nextRetarget = Time.time + retargetRate;
            foreach (Collider2D i in Physics2D.OverlapCircleAll(transform.position, targetRange))
            {
                if(i.tag == "Mouse")
                {
                    target = i.GetComponent<AbsHealth>();
                    break;
                }
            }

        }
        if (target)
        {
            Vector3 endRotation = transform.eulerAngles;
            endRotation.z = Vector2.Angle(Vector2.up, transform.position - target.transform.position) * (((transform.position - target.transform.position).x < 0) ? 1f : -1f) + 180;
            transform.localEulerAngles = endRotation;
            rb.AddRelativeForce(Vector2.up * moveForce);

            if(nextAttack < Time.time)
            {
                nextAttack = Time.time + attackRate;
                if(attacker) attacker.attack(target);
            }
        }
	}
}
