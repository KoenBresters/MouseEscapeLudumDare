﻿using UnityEngine;

public class ShortActivate : MonoBehaviour {

    private bool acitvate1Timer = false;
    private bool acitvate2Timer = false;
    private bool hasShortted = false;
    public GameObject particle;
    public TimeMessage a;
    public TimeMessage b;
    public GameObject wall;

    public void activate1()
    {
        acitvate1Timer = true;
    }

    public void activate2()
    {
        acitvate2Timer = true;
    }

    private void Update()
    {
        if(!hasShortted && acitvate1Timer && acitvate2Timer)
        {
            hasShortted = true;
            foreach(ScreenRelese i in FindObjectsOfType<ScreenRelese>())
            {
                if(!i.is_arcade) i.Relese();
            }

            foreach (LoneMouseAI i in FindObjectsOfType<LoneMouseAI>())
            {
                i.followPlayer();
            }
            Instantiate(particle, transform.position, Quaternion.identity);
            a.start();
            b.start();
            wall.SetActive(false);
        }
    }
}
