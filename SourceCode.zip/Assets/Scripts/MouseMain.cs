﻿using UnityEngine;

public class MouseMain : MonoBehaviour {

    public bool isPlayer;
    [Header("playerData")]
    public float goToMouseForce;
    public Rigidbody2D rb;
    public float stopDistance = 2f;
    [Header("notPlayer")]
    public LoneMouseAI.state startState;
    public float moveForce;
    public float idleMoveForce;
    public float directionChangeRate;
    public float rotationSpeed;
    public AbsMouseAI ai;
    public AbsAttack attacker;
    public float attackTime;
    public float EnimyDistance;
    public float minAttackDistance = Mathf.Infinity;

    private void OnMouseOver()
    {
        if (!isPlayer && Input.GetMouseButtonDown(1))
        {
            Manager.current.SetPlayer(this);
        }
    }

    private void Start()
    {
        if (isPlayer)
        {
            if(!(ai is PlayerMouseAI))
            {
                Destroy(ai);
                ai = gameObject.AddComponent<PlayerMouseAI>();
            }
            PlayerMouseAI playerAI = ai as PlayerMouseAI;
            playerAI.goToMouseForce = goToMouseForce;
            playerAI.rb = rb;
            playerAI.stopDistance = stopDistance;
            playerAI.attacker = attacker;
            playerAI.attackTime = attackTime;
        }
        else
        {
            if (!(ai is LoneMouseAI))
            {
                Destroy(ai);
                ai = gameObject.AddComponent<LoneMouseAI>();
            }
            LoneMouseAI loneAI = ai as LoneMouseAI;
            loneAI.moveForce = moveForce;
            loneAI.rb = rb;
            loneAI.stopDistance = stopDistance;
            loneAI.directionChangeRate = directionChangeRate;
            loneAI.rotationSpeed = rotationSpeed;
            loneAI.IdleMoveForce = idleMoveForce;
            loneAI.nowState = startState;
            loneAI.attacker = attacker;
            loneAI.attackTime = attackTime;
            loneAI.EnimyDistance = EnimyDistance;
            loneAI.MinAttackDistance = minAttackDistance;
}
    }

    public void setPlayer(bool to)
    {
        if(to != isPlayer)
        {
            isPlayer = to;
            if (to)
            {
                Destroy(ai);
                ai = gameObject.AddComponent<PlayerMouseAI>();
                PlayerMouseAI playerAI = ai as PlayerMouseAI;
                playerAI.goToMouseForce = goToMouseForce;
                playerAI.rb = rb;
                playerAI.stopDistance = stopDistance;
                playerAI.attacker = attacker;
                playerAI.attackTime = attackTime;
            }
            else
            {
                Destroy(ai);
                ai = gameObject.AddComponent<LoneMouseAI>();
                LoneMouseAI loneAI = ai as LoneMouseAI;
                loneAI.moveForce = moveForce;
                loneAI.rb = rb;
                loneAI.stopDistance = stopDistance;
                loneAI.directionChangeRate = directionChangeRate;
                loneAI.rotationSpeed = rotationSpeed;
                loneAI.IdleMoveForce = idleMoveForce;
                loneAI.nowState = LoneMouseAI.state.FollowingPlayer;
                loneAI.attacker = attacker;
                loneAI.attackTime = attackTime;
                loneAI.EnimyDistance = EnimyDistance;
            }
        }
    }
}
