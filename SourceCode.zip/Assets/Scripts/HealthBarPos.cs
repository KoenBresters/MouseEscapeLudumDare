﻿using UnityEngine;

public class HealthBarPos : MonoBehaviour {

    public float upValue;

    private void Update()
    {
        transform.position = transform.parent.position + Vector3.up * upValue;
        transform.rotation = Quaternion.identity;
    }
}
