﻿using UnityEngine;

public class SimpleMouseAttack : AbsAttack {

    public float force;
    public float OnHitDamage;
    public float damageTime;
    private float damageTimer;
    public Rigidbody2D rb;
    private AbsHealth nowTarget;

    private void Update()
    {
        if(damageTimer > 0)
        {
            damageTimer -= Time.deltaTime;
        }
    }

    public override void attack(AbsHealth who)
    {
        rb.AddRelativeForce(Vector2.up * force, ForceMode2D.Impulse);
        damageTimer = damageTime;
        nowTarget = who;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(damageTimer > 0 && ((nowTarget && collision.gameObject == nowTarget.gameObject)||(!nowTarget && collision.transform.root.tag != "Mouse")))
        {
            if (nowTarget) nowTarget.damage(OnHitDamage, gameObject);
            else if (collision.gameObject.GetComponent<AbsHealth>()) collision.gameObject.GetComponent<AbsHealth>().damage(OnHitDamage, gameObject);
            damageTimer = 0f;
        }
    }
}
