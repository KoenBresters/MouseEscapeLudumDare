﻿using UnityEngine;

public class LetterDamage : MonoBehaviour
{
    public float damage;
    public string ignoreTag;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag != ignoreTag)
        {
            if(collision.gameObject.GetComponent<AbsHealth>()) collision.gameObject.GetComponent<AbsHealth>().damage(damage, gameObject);
            Destroy(gameObject);
        }
    }
}