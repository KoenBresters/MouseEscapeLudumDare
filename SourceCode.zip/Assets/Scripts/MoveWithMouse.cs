﻿using UnityEngine;

public class MoveWithMouse : MonoBehaviour {

    public float lerpSpeed = 0.5f;

    private void Update()
    {
        if (Manager.current.player)
        {
            Vector3 OnRectPoint;
            Plane a = new Plane(Vector3.zero, Vector3.up, Vector3.right);
            float b;
            Ray r = new Ray(transform.position, transform.forward);
            if (a.Raycast(r, out b)) OnRectPoint = r.GetPoint(b);
            else throw new System.Exception("could't raycast");
            Vector3 c = Manager.current.player.transform.position;
            c.z = 0;
            transform.Translate(Vector3.Lerp(OnRectPoint, c, lerpSpeed * Time.deltaTime) - OnRectPoint, Space.World);
        }
        
    }
}
