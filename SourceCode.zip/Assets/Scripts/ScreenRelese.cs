﻿using UnityEngine;

public class ScreenRelese : MonoBehaviour {

    public Collider2D[] colliders;
    public GameObject ParticlePrefab;
    public bool is_arcade = false;

    public void Relese()
    {
        foreach(Collider2D i in colliders)
        {
            i.gameObject.layer = 9;
        }
        if(ParticlePrefab) Instantiate(ParticlePrefab, transform, false);
    }
}
