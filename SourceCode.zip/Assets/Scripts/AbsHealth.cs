﻿using UnityEngine;

public abstract class AbsHealth : MonoBehaviour {

    public float health;
    [HideInInspector]
    public float max_health;
    private bool has_died = false;

    private void Start()
    {
        max_health = health;
    }
    public virtual void damage(float amt, GameObject by)
    {
        health -= amt;
        if(!has_died && health <= 0)
        {
            has_died = true;
            onDeath(by);
        }
    }

    public abstract void onDeath(GameObject by);
}
