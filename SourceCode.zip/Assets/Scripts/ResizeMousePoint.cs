﻿using UnityEngine;

public class ResizeMousePoint : MonoBehaviour {

    private ResizeMousePoint brother;
    private ResizeMouseAttack owner;
    private Rigidbody2D connectedToRigidbody;
    private bool isPulling = false;
    public float pullForce;

    public bool hasAttached { private set; get; }

    public void SendHasAttached()
    {
        if(hasAttached && brother.hasAttached)
        {
            isPulling = true;
            Destroy(GetComponent<ConstantForce2D>());
        }
    }

    private void Update()
    {
        if (isPulling)
        {
            if (connectedToRigidbody)
            {
                connectedToRigidbody.AddForceAtPosition(((Vector2)owner.transform.position-connectedToRigidbody.position).normalized * pullForce, transform.position);
            }
            else
            {
                owner.GetComponent<Rigidbody2D>().AddForce((transform.position - owner.transform.position).normalized * pullForce);
            }
        }
    }

    public void init(ResizeMouseAttack _owner, ResizeMousePoint _brother)
    {
        owner = _owner;
        brother = _brother;
        hasAttached = false;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(!hasAttached && !other.isTrigger && other.tag != "Mouse" && other.tag != "ResizerPoint")
        {
            FixedJoint2D a = gameObject.AddComponent<FixedJoint2D>();
            if (other.GetComponent<Rigidbody2D>()) {
                a.connectedBody = connectedToRigidbody = other.GetComponent<Rigidbody2D>();
            }
            hasAttached = true;
            brother.SendHasAttached();
            SendHasAttached();
        }
    }
}
