﻿using UnityEngine;

public class PlayerMouseAI : AbsMouseAI {

    public float goToMouseForce;
    public Rigidbody2D rb;
    public float stopDistance = 2f;
    public AbsAttack attacker;
    public float attackTime;
    private float nextAttack = 0f;

    private void FixedUpdate()
    {
        Vector3 outPoint;
        RectTransformUtility.ScreenPointToWorldPointInRectangle(Manager.current.screen, Input.mousePosition, Camera.main, out outPoint);
        Vector3 endRotation = transform.eulerAngles;
        endRotation.z = Vector2.Angle(Vector2.up, transform.position - outPoint) * (((transform.position - outPoint).x < 0)? 1f : -1f) + 180;
        transform.localEulerAngles = endRotation;
        if (Vector3.Distance(outPoint, transform.position) > stopDistance) {
            rb.AddRelativeForce(Vector2.up * goToMouseForce);
        }
    }

    private void Update()
    {
        if(nextAttack < Time.time && Input.GetMouseButtonDown(0))
        {
            attacker.attack(null);
            nextAttack = attackTime + Time.time;
        }
    }
}
