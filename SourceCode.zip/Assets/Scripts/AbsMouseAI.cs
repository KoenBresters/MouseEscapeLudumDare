﻿using UnityEngine;

public abstract class AbsMouseAI : MonoBehaviour {

	
}
