﻿using UnityEngine;

public class LoneMouseAI : AbsMouseAI {

    public state nowState;
    public Rigidbody2D rb;
    public float moveForce;
    public float IdleMoveForce;
    public float stopDistance;
    private float nextDirectionChange;
    public float directionChangeRate;
    public float rotationSpeed;
    private float lastRotation;
    private float newRotation;
    private float interpolationProgress;
    public AbsHealth target;
    public AbsAttack attacker;
    public float attackTime;
    public float EnimyDistance;
    public float MinAttackDistance;
    private float nextAttack = 0f;

    private void Start()
    {
        nextDirectionChange = Time.time + directionChangeRate;
        lastRotation = 0f;
        nextAttack = Time.time + attackTime; 
        interpolationProgress = 0f;
    }

    public void attack(AbsHealth target)
    {
        this.target = target;
        nowState = state.fighting;
    }

    public void followPlayer()
    {
        nowState = state.FollowingPlayer;
    }

    // Update is called once per frame
    void Update () {
		if(nowState == state.Idle)
        {
            if(nextDirectionChange < Time.time)
            {
                nextDirectionChange = Time.time + directionChangeRate;
                lastRotation = newRotation;
                newRotation = Random.Range(-180f, 180f);
                interpolationProgress = 0f;
                
            }
            if (interpolationProgress <= 1f) interpolationProgress += rotationSpeed * Time.deltaTime;
            else if (interpolationProgress != 1f) interpolationProgress = 1f;
            transform.localEulerAngles = new Vector3(0f, 0f, Mathf.Lerp(lastRotation, newRotation, interpolationProgress));
            rb.AddRelativeForce(Vector2.up * IdleMoveForce);

        }
        else if (nowState == state.FollowingPlayer)
        {
            if (Manager.current.player)
            {
                Vector3 endRotation = transform.eulerAngles;
                endRotation.z = Vector2.Angle(Vector2.up, transform.position - Manager.current.player.transform.position) * (((transform.position - Manager.current.player.transform.position).x < 0) ? 1f : -1f) + 180;
                transform.localEulerAngles = endRotation;
            }
            if (Vector3.Distance(Manager.current.player.transform.position, transform.position) > stopDistance)
            {
                rb.AddRelativeForce(Vector2.up * moveForce);
            }
        }else if(nowState == state.fighting)
        {
            if (!target)
            {
                nowState = state.Idle;
            }
            else
            {
                Vector3 endRotation = transform.eulerAngles;
                endRotation.z = Vector2.Angle(Vector2.up, transform.position - target.transform.position) * (((transform.position - target.transform.position).x < 0) ? 1f : -1f) + 180;
                transform.localEulerAngles = endRotation;
                float d = Vector3.Distance(target.transform.position, transform.position);
                if (d > EnimyDistance)
                {
                    rb.AddRelativeForce(Vector2.up * moveForce);
                }
                if (d < MinAttackDistance && nextAttack < Time.time)
                {
                    attacker.attack(null);
                    nextAttack = attackTime + Time.time;
                }
            }
        }
	}

    public enum state
    {
        Stopped, Idle, FollowingPlayer, fighting
    }
}
