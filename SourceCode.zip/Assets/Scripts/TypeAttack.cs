﻿using UnityEngine;
using UnityEngine.UI;

public class TypeAttack : AbsAttack {

    public GameObject letterPrefab;
    private char[] alfabet = "abcdefghijklmnopqrstuvwxyz1234567890!@#$%^&*(),.<>/?;:/{[}]=+-_".ToCharArray();

    public override void attack(AbsHealth who)
    {
        GameObject a = Instantiate(letterPrefab, transform.position, Quaternion.identity);
        if(who)
        {
            Vector3 endRotation = a.transform.eulerAngles;
            endRotation.z = Vector2.Angle(Vector2.up, a.transform.position - who.transform.position) * (((a.transform.position - who.transform.position).x < 0) ? 1f : -1f) + 180;
            a.transform.localEulerAngles = endRotation;
        }
        else
        {
            a.transform.rotation = transform.rotation;
        }
        

        a.transform.GetChild(0).GetChild(0).GetComponent<Text>().text = alfabet[Random.Range(0, alfabet.Length)].ToString();
    }
}
