﻿using UnityEngine;

public class TimeMessage : MonoBehaviour {

    public bool autoStart;
    public float whaitTime;
    public string text;
    public float secPerLetter;
    public float endStayTime;
    private float SayMoment = Mathf.Infinity;
    private bool hasSaid = false;

    private void Start()
    {
        if (autoStart)
        {
            start();
        }
    }

    private void Update()
    {
        if (!hasSaid && Time.time > SayMoment) {
            Manager.current.say(text, secPerLetter, endStayTime);
            hasSaid = true;
        }
    }

    public void start()
    {
        SayMoment = Time.time + whaitTime;
    }

    private void Pstart()
    {
        SayMoment = Time.time + whaitTime;
    }
}
