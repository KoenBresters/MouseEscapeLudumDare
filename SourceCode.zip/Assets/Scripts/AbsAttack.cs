﻿using UnityEngine;

public abstract class AbsAttack : MonoBehaviour {

    public abstract void attack(AbsHealth who);
}
