﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using UnityEngine.SceneManagement;

public class Manager : MonoBehaviour {

    public static Manager current;
    public Transform cam;
    public RectTransform screen;
    public Text saytext;
    public GameObject player;
    public GameObject playerScreen;
    public GameObject brokenParcle;
    public TimeMessage messageSender1;
    public TimeMessage messageSender2;
    public SceneFader fader;
    public Animator UIanimation;
    public AbsHealth PacMan;
    private bool hasExited = false;
    public GameObject thanksText;

    private void Awake()
    {
        current = this;
        Physics2D.IgnoreLayerCollision(8, 9);
    }

    private void Update()
    {
        if (!hasExited && !player)
        {
            hasExited = true;
            fader.FadeTo(SceneManager.GetActiveScene().name);
        }
        if (!hasExited && !PacMan)
        {
            hasExited = true;
            thanksText.SetActive(true);
            fader.FadeTo(SceneManager.GetActiveScene().name);
        }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }
    }

    public void GameStart()
    {
        messageSender1.start();
        messageSender2.start();
        Camera.main.GetComponent<MoveWithMouse>().enabled = true;
        UIanimation.SetBool("StartGame", true);
        StartCoroutine(whaitABit());
    }

    public void attackPac()
    {
        foreach(Collider2D i in Physics2D.OverlapCircleAll(Vector2.zero, Mathf.Infinity))
        {
            if (i.GetComponent<MouseMain>())
            {
                if(i.GetComponent<MouseMain>().ai is LoneMouseAI)
                {
                    (i.GetComponent<MouseMain>().ai as LoneMouseAI).attack(PacMan);
                }
            }
        }
    }

    private IEnumerator whaitABit()
    {
        yield return new WaitForSeconds(1);
        playerScreen.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Dynamic;
    }

    public void say(string text, float secPerLetter, float endStaySec)
    {
        StartCoroutine(StartSay(text, secPerLetter, endStaySec));
    }

    private IEnumerator StartSay(string text, float secPerLetter, float endStaySec)
    {
        WaitForSeconds a = new WaitForSeconds(secPerLetter);
        foreach (char i in text.ToCharArray())
        {
            saytext.text = saytext.text + i;
            yield return a;
        }
        yield return new WaitForSeconds(endStaySec);
        saytext.text = "";
    }

    public void screenHitTable()
    {
        for (int i = 0; i < playerScreen.transform.childCount; i++)
        {
            Physics2D.IgnoreCollision(player.GetComponent<Collider2D>(), playerScreen.transform.GetChild(i).GetComponent<Collider2D>(), true);
        }
        Instantiate(brokenParcle, playerScreen.transform, false);
    }

    public void SetPlayer(MouseMain main)
    {
        player.GetComponent<MouseMain>().setPlayer(false);
        player = main.gameObject;
        main.setPlayer(true);
    }
}
