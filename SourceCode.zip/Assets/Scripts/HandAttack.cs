﻿using UnityEngine;
using System.Collections.Generic;

public class HandAttack : AbsAttack {

    public float range;
    public float hitForce;
    public float damage;
    public string[] ignoreTags;
    private float oldZ;
    public float maxHeight;
    public float jumpSpeed;
    public AnimationCurve curve;
    private float curveProgress;
    private bool isJumping;

    private void Start()
    {
        oldZ = transform.position.z;
    }

    private void Update()
    {
        if (isJumping)
        {
            curveProgress += jumpSpeed * Time.deltaTime;
            transform.position = new Vector3(transform.position.x, transform.position.y, Mathf.Lerp(oldZ, oldZ - maxHeight, curve.Evaluate(curveProgress)));

            if (curveProgress >= 1f)
            {
                isJumping = false;
                transform.position = new Vector3(transform.position.x, transform.position.y, oldZ);
                DoAttack();
            }
        }
    }

    public override void attack(AbsHealth who)
    {
        isJumping = true;
        curveProgress = 0f;
    }


    private void DoAttack()
    {
        List<string> a = new List<string>(ignoreTags);
        foreach (Collider2D i in Physics2D.OverlapCircleAll(transform.position, range))
        {
            if (!a.Contains(i.transform.root.tag) && i.GetComponent<AbsHealth>() != null)
                i.GetComponent<AbsHealth>().damage(damage, gameObject);
            if (i.GetComponent<Rigidbody2D>() != null)
            {
                i.GetComponent<Rigidbody2D>().AddForce((transform.position - i.transform.position).normalized *
                    hitForce * (1 - (Vector2.Distance(transform.position, i.bounds.ClosestPoint(transform.position) / range))));
            }
        }
    }
}
