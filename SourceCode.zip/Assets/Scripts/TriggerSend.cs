﻿using UnityEngine;

public class TriggerSend : MonoBehaviour {

    public string wantTag;
    public Behaviour toSendTo;
    public string methodName;
    private bool hasSend = false;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!hasSend && other.transform.root.tag.Equals(wantTag))
        {
            hasSend = true;
            toSendTo.SendMessage(methodName);
        }
    }

}
