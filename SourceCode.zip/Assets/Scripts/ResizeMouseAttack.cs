﻿using UnityEngine;

public class ResizeMouseAttack : AbsAttack {

    private AbsHealth target;
    private bool isAttacking = false;
    public SpriteRenderer rend;
    private GameObject arrow1;
    private GameObject arrow2;
    public LineRenderer line;
    public GameObject arrowPrefab;

    private void Start()
    {
        line.numPositions = 3;
        line.SetPositions(new Vector3[] { new Vector2(0, 0), new Vector2(0, 0), new Vector2(0, 0) });
    }

    public override void attack(AbsHealth who)
    {
        if (!isAttacking) {
            target = who;
            isAttacking = true;
            rend.enabled = false;
            line.enabled = true;
            arrow1 = Instantiate(arrowPrefab, transform.position, transform.rotation);
            arrow2 = Instantiate(arrowPrefab, transform.position, Quaternion.Euler(transform.eulerAngles + new Vector3(0, 0, 180)));
            arrow1.GetComponent<ResizeMousePoint>().init(this, arrow2.GetComponent<ResizeMousePoint>());
            arrow2.GetComponent<ResizeMousePoint>().init(this, arrow1.GetComponent<ResizeMousePoint>());
        }
        else if (!target)
        {
            isAttacking = false;
            Destroy(arrow1);
            Destroy(arrow2);
            rend.enabled = true;
            line.enabled = false;
        }
    }

    private void Update()
    {
        if (isAttacking)
        {
            line.SetPosition(1, transform.position);
            line.SetPosition(0, arrow1.transform.position);
            line.SetPosition(2, arrow2.transform.position);
        }
    }

    private void OnDestroy()
    {
        if (arrow1) Destroy(arrow1);
        if (arrow2) Destroy(arrow2);
    }
}
