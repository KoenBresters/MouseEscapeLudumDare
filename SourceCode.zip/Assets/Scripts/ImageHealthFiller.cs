﻿using UnityEngine.UI;
using UnityEngine;

public class ImageHealthFiller : MonoBehaviour {

    public Image image;
    public AbsHealth health;

    private void Update()
    {
        image.fillAmount = health.health / health.max_health;
    }
}
