﻿using UnityEngine;

public class TimeDestroy : MonoBehaviour {

	public float time_alive = 1;
    private float destroy_moment;
    // Use this for initialization
	void Start () {
        destroy_moment = Time.time + time_alive;
	}
	
	// Update is called once per frame
	void Update () {
		if(Time.time > destroy_moment)
        {
            Destroy(gameObject);
        }
	}
}
